<?php

$_lang['ajaxsnippet'] = 'AjaxSnippet';

$_lang['as_trigger'] = 'Загрузить контент!';