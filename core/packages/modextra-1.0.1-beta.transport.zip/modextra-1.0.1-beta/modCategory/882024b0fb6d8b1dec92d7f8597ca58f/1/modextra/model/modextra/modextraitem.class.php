<?php

/**
 * @package modextra
 */
class modExtraItem extends xPDOSimpleObject
{
}